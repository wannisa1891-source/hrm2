import { NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/hrm_db';
// @ts-ignore
import bcrypt from 'bcryptjs';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    // รับ email, password ตามที่กำหนด (รองรับ username จาก frontend ด้วย)
    const email = body.email || body.username;
    const password = body.password;

    console.log('📥 LOGIN INPUT:', { email });

    // 1. รับ email, password
    if (!email || !password) {
      return NextResponse.json(
        { success: false, message: 'กรุณากรอกข้อมูลให้ครบถ้วน' },
        { status: 400 }
      );
    }

    // 2. query จาก tbl_users โดยใช้ username
    const [rows]: any = await pool.query(
      'SELECT * FROM tbl_users WHERE username = ?',
      [email]
    );

    console.log('📊 DB RESULT:', rows);

    // 3. ถ้าไม่เจอ -> 401
    if (rows.length === 0) {
      console.log('❌ User not found');
      return NextResponse.json(
        { success: false, message: 'ไม่พบผู้ใช้งานในระบบ' },
        { status: 401 }
      );
    }

    const user = rows[0];

    console.log('🔐 HASH IN DB:', user.password_hash);

    // 4. compare password กับ password_hash ด้วย bcryptjs
    const isMatch = await bcrypt.compare(password, user.password_hash);
    console.log('🔍 COMPARE RESULT:', isMatch);

    // 5. ถ้าไม่ตรง -> 401
    if (!isMatch) {
      console.log('❌ Wrong password');
      return NextResponse.json(
        { success: false, message: 'รหัสผ่านไม่ถูกต้อง' },
        { status: 401 }
      );
    }

    const mockToken = `token_${user.user_id}_${Date.now()}`;
    console.log('✅ LOGIN SUCCESS');

    // 6. ถ้าถูก -> login success (ห้ามส่ง password_hash กลับ frontend)
    return NextResponse.json({
      success: true,
      message: 'เข้าสู่ระบบสำเร็จ',
      token: mockToken,
      user: {
        id: user.user_id,
        name: user.name,
        email: user.username,
        role: user.role
      }
    });

  } catch (error: any) {
    console.error('🔥 LOGIN ERROR:', error);
    return NextResponse.json(
      { success: false, message: 'เกิดข้อผิดพลาดในการเข้าสู่ระบบ', error: error.message },
      { status: 500 }
    );
  }
}
