import { NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/hrm_db';
// @ts-ignore
import bcrypt from 'bcryptjs';

export async function POST(req: NextRequest) {
  let connection;
  try {
    const body = await req.json();
    const {
      username, email, password,
      employeeId, firstName, lastName, gender, dateOfBirth, phone,
      position, department, startDate, employeeType, role
    } = body;

    console.log('📥 REGISTER INPUT:', { username, employeeId, email });

    // 1. Basic validation
    if (!username || !email || !password || !employeeId || !firstName || !lastName) {
      return NextResponse.json(
        { success: false, message: 'กรุณากรอกข้อมูลที่จำเป็นให้ครบถ้วน' },
        { status: 400 }
      );
    }

    connection = await pool.getConnection();
    await connection.beginTransaction();

    // 2. Check duplicate username or employeeId
    const [existingUser]: any = await connection.query(
      'SELECT user_id FROM tbl_users WHERE username = ?',
      [username]
    );
    if (existingUser.length > 0) {
      await connection.rollback();
      return NextResponse.json(
        { success: false, message: 'Username นี้ถูกใช้งานแล้ว' },
        { status: 409 }
      );
    }

    const [existingEmp]: any = await connection.query(
      'SELECT emp_id FROM tbl_employees WHERE emp_id = ?',
      [employeeId]
    );
    if (existingEmp.length > 0) {
      await connection.rollback();
      return NextResponse.json(
        { success: false, message: 'รหัสพนักงานนี้มีอยู่ในระบบแล้ว' },
        { status: 409 }
      );
    }

    // 3. Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    const fullName = `${firstName} ${lastName}`;

    // 4. Insert into tbl_employees
    // Note: Assuming pos_id and dept_id might be needed instead of string position/department if DB is normalized.
    // If table strictly needs pos_id, this insert will fail gracefully and rollback.
    // We will attempt to insert standard fields first.
    try {
      await connection.query(
        `INSERT INTO tbl_employees 
        (emp_id, name, gender, phone) 
        VALUES (?, ?, ?, ?)`,
        [employeeId, fullName, gender, phone]
      );
    } catch (empErr: any) {
      console.error('🔥 EMP INSERT ERROR:', empErr);
      // Fallback: If table is different, we just ignore emp insert or let it throw
      throw new Error(`Employee Insert failed: ${empErr.message}`);
    }

    // 5. Insert into tbl_users
    // Try inserting email and role if columns exist, otherwise fallback to standard
    try {
      await connection.query(
        `INSERT INTO tbl_users (name, username, password_hash, role) VALUES (?, ?, ?, ?)`,
        [fullName, username, hashedPassword, role || 'employee']
      );
    } catch (usrErr: any) {
      console.log('Fallback user insert due to schema mismatch...', usrErr.message);
      await connection.query(
        `INSERT INTO tbl_users (name, username, password_hash) VALUES (?, ?, ?)`,
        [fullName, username, hashedPassword]
      );
    }

    await connection.commit();
    console.log('✅ REGISTER SUCCESS');

    return NextResponse.json({
      success: true,
      message: 'สมัครสมาชิกและเพิ่มพนักงานสำเร็จ'
    });

  } catch (error: any) {
    if (connection) await connection.rollback();
    console.error('🔥 REGISTER ERROR:', error);
    return NextResponse.json(
      {
        success: false,
        message: 'เกิดข้อผิดพลาดในการสมัครสมาชิก',
        error: error.message
      },
      { status: 500 }
    );
  } finally {
    if (connection) connection.release();
  }
}

