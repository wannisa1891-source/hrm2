export const register = async (name: string, email: string, password: string) => {
  try {
    const response = await fetch('http://localhost:8000/api/auth/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({ name, email, password })
    })

    if (response.ok) {
      const data = await response.json()
      return { success: true, user: data.user }
    } else {
      const errorData = await response.json().catch(() => ({}))
      return { success: false, message: errorData.message || 'สมัครไม่สำเร็จ' }
    }
  } catch (error) {
    console.error('Register Error:', error)
    return { success: false, message: 'เชื่อมต่อเซิร์ฟเวอร์ไม่ได้' }
  }
}